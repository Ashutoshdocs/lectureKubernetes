# PodDisruptionBudget (PDB) Lab — 2-Node Kubernetes Cluster

A hands-on demo that shows what a PodDisruptionBudget does, how it paces a
`kubectl drain`, and how a badly written PDB can block node maintenance.

**Time:** ~30 minutes  **Level:** beginner–intermediate

---

## 1. Concepts in 60 seconds

| Term | Meaning |
|------|---------|
| **Voluntary disruption** | Something an admin/tool chooses to do: `kubectl drain`, node upgrade, cluster-autoscaler scale-down. These go through the **Eviction API** and **respect PDBs**. |
| **Involuntary disruption** | Node crash, kernel panic, OOM, power loss. **PDBs cannot prevent these.** |
| **PDB** | A rule: "for pods matching this selector, keep at least N available" (`minAvailable`) or "never take down more than N at once" (`maxUnavailable`). |
| **ALLOWED DISRUPTIONS** | Live value computed by Kubernetes = how many pods may be evicted *right now*. If it is `0`, evictions are refused (HTTP 429) and `drain` keeps retrying. |

> ⚠️ `kubectl delete pod` does **not** use the Eviction API — it ignores PDBs.
> Only evictions (drain, autoscaler, `kubectl evict` plugins, etc.) are protected.

---

## 2. Files

| File | Purpose |
|------|---------|
| `kind-2node.yaml` | Optional: creates a local 2-node cluster with kind |
| `00-namespace.yaml` | `pdb-demo` namespace |
| `01-deployment.yaml` | `web` Deployment, 4 replicas spread 2 + 2 across nodes |
| `02-pdb-minavailable.yaml` | Scenario A — `minAvailable: 3` |
| `03-pdb-maxunavailable.yaml` | Scenario B — `maxUnavailable: 1` + `unhealthyPodEvictionPolicy` |
| `04-pdb-zero-disruption.yaml` | Scenario C — `maxUnavailable: 0` (blocks drains) |
| `05-single-replica.yaml` | Scenario D — 1 replica + `minAvailable: 1` (the classic trap) |

---

## 3. Prerequisites — a 2-node cluster

**Option 1 – kind (local):**

```bash
kind create cluster --name pdb-lab --config kind-2node.yaml
kubectl get nodes
```

**Option 2 – existing kubeadm / minikube / cloud cluster with 2 nodes.**
For minikube: `minikube start --nodes 2 -p pdb-lab`

### Let both nodes run workloads

If one of your two nodes is a control-plane node, it is usually tainted so
regular pods won't land there. For this lab we want pods on **both** nodes:

```bash
kubectl get nodes
kubectl describe nodes | grep -i taint

# remove the control-plane taint (lab clusters only!)
kubectl taint nodes --all node-role.kubernetes.io/control-plane:NoSchedule- || true
```

Save the node names for later:

```bash
NODE1=$(kubectl get nodes -o jsonpath='{.items[0].metadata.name}')
NODE2=$(kubectl get nodes -o jsonpath='{.items[1].metadata.name}')
echo "NODE1=$NODE1  NODE2=$NODE2"
```

---

## 4. Deploy the app

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-deployment.yaml
kubectl rollout status deploy/web -n pdb-demo
kubectl get pods -n pdb-demo -o wide
```

Expected: 4 pods, roughly **2 on each node**.

> 💡 Open a **second terminal** and keep these running for the whole lab:
>
> ```bash
> kubectl get pods -n pdb-demo -o wide -w
> ```
> ```bash
> watch -n1 kubectl get pdb -n pdb-demo
> ```

---

## 5. Baseline — drain WITHOUT a PDB

```bash
kubectl drain $NODE2 --ignore-daemonsets --delete-emptydir-data
```

**Observe:** both pods on `$NODE2` are evicted **at the same time**. For ~10 s
(the readiness delay) only 2 of 4 pods are serving. With a real app that
could be an outage.

Restore:

```bash
kubectl uncordon $NODE2
kubectl rollout restart deploy/web -n pdb-demo   # re-spread pods 2 + 2
kubectl rollout status deploy/web -n pdb-demo
kubectl get pods -n pdb-demo -o wide
```

> Kubernetes does **not** move pods back automatically after uncordon —
> that's why we restart the rollout.

---

## 6. Scenario A — `minAvailable: 3`

```bash
kubectl apply -f 02-pdb-minavailable.yaml
kubectl get pdb -n pdb-demo
```

```
NAME      MIN AVAILABLE   MAX UNAVAILABLE   ALLOWED DISRUPTIONS   AGE
web-pdb   3               N/A               1                     5s
```

4 healthy − 3 required = **1 allowed disruption**.

Now drain:

```bash
kubectl drain $NODE2 --ignore-daemonsets --delete-emptydir-data
```

**Observe:**
1. Drain evicts **one** pod → `ALLOWED DISRUPTIONS` drops to `0`.
2. Drain prints: `error when evicting pods/"web-..." ... Cannot evict pod as it would violate the pod's disruption budget. ... will retry after 5s`
3. The replacement starts on `$NODE1`, becomes Ready (~10 s) → allowed goes back to `1`.
4. Drain evicts the second pod. Drain completes.

At no point were fewer than 3 pods serving. ✅ That is the whole point of a PDB.

Restore:

```bash
kubectl uncordon $NODE2
kubectl rollout restart deploy/web -n pdb-demo && kubectl rollout status deploy/web -n pdb-demo
```

---

## 7. Scenario B — `maxUnavailable: 1`

```bash
kubectl apply -f 03-pdb-maxunavailable.yaml   # replaces web-pdb
kubectl get pdb -n pdb-demo
```

Same pacing as Scenario A, but expressed relative to replica count. Try:

```bash
kubectl scale deploy/web -n pdb-demo --replicas=6
kubectl get pdb -n pdb-demo     # still ALLOWED DISRUPTIONS = 1
```

With `minAvailable: 3` and 6 replicas you would get 3 allowed disruptions —
`maxUnavailable` keeps the "one at a time" guarantee no matter the scale.

Drain to confirm, then restore:

```bash
kubectl drain $NODE2 --ignore-daemonsets --delete-emptydir-data
kubectl uncordon $NODE2
kubectl scale deploy/web -n pdb-demo --replicas=4
kubectl rollout restart deploy/web -n pdb-demo && kubectl rollout status deploy/web -n pdb-demo
```

**`unhealthyPodEvictionPolicy: AlwaysAllow`** — pods that are running but not
Ready (e.g. CrashLooping) can be evicted even when the budget is exhausted.
Without it, a single broken pod can block node maintenance.

---

## 8. Scenario C — `maxUnavailable: 0` (blocks everything)

```bash
kubectl apply -f 04-pdb-zero-disruption.yaml
kubectl get pdb -n pdb-demo     # ALLOWED DISRUPTIONS = 0

kubectl drain $NODE2 --ignore-daemonsets --delete-emptydir-data --timeout=60s
```

**Observe:** drain cordons the node, then retries forever until the timeout:

```
error: unable to drain node "...": ... global timeout reached: 1m0s
```

The node is left **cordoned but not drained**. In a real cluster this
stalls node upgrades and cluster-autoscaler scale-down.

Now prove PDBs only guard the Eviction API:

```bash
POD=$(kubectl get pod -n pdb-demo -l app=web -o jsonpath='{.items[0].metadata.name}')
kubectl delete pod $POD -n pdb-demo    # succeeds immediately — PDB ignored
```

Restore:

```bash
kubectl uncordon $NODE2
```

---

## 9. Scenario D — the single-replica trap

```bash
kubectl apply -f 02-pdb-minavailable.yaml     # put a sane PDB back on "web"
kubectl apply -f 05-single-replica.yaml
kubectl rollout status deploy/solo -n pdb-demo
kubectl get pdb -n pdb-demo
kubectl get pod -n pdb-demo -l app=solo -o wide   # note which node it's on
```

`solo-pdb` shows **ALLOWED DISRUPTIONS = 0** forever (1 healthy − 1 required).

Drain the node running `solo`:

```bash
SOLO_NODE=$(kubectl get pod -n pdb-demo -l app=solo -o jsonpath='{.items[0].spec.nodeName}')
kubectl drain $SOLO_NODE --ignore-daemonsets --delete-emptydir-data --timeout=60s
```

**Observe:** `web` pods are evicted one by one (Scenario A), but `solo` blocks
the drain. Fixes, from best to worst:

1. Run ≥ 2 replicas (`kubectl scale deploy/solo -n pdb-demo --replicas=2`).
2. Use `maxUnavailable: 1` and accept brief downtime for a singleton.
3. Don't create a PDB for single-replica workloads.

Try fix #1 and drain again — it now completes.

```bash
kubectl uncordon $SOLO_NODE
```

---

## 10. Why 2 nodes makes this interesting

- When one node is drained, **all** replacement pods must fit on the other
  node. Size requests so one node can hold the whole workload, or drains
  will wait on Pending pods.
- The Deployment uses `topologySpreadConstraints` with
  `whenUnsatisfiable: ScheduleAnyway`. With `DoNotSchedule`, replacements
  could refuse to stack on the remaining node → Pending → PDB never
  frees up → drain hangs.
- Good rule for small clusters: `maxUnavailable: 1` on apps with ≥ 2 replicas.

---

## 11. Cheat sheet

```bash
kubectl get pdb -A
kubectl describe pdb web-pdb -n pdb-demo     # shows current/desired healthy, disruptions allowed
kubectl get pdb web-pdb -n pdb-demo -o yaml  # .status section
kubectl drain <node> --ignore-daemonsets --delete-emptydir-data [--timeout=120s]
kubectl uncordon <node>
```

| Field | Accepts | Notes |
|-------|---------|-------|
| `minAvailable` | int or `%` | Can't be used together with `maxUnavailable` |
| `maxUnavailable` | int or `%` | Preferred for scaling workloads |
| `selector` | label selector | Should match exactly one workload's pods |
| `unhealthyPodEvictionPolicy` | `IfHealthyBudget` (default) / `AlwaysAllow` | `AlwaysAllow` recommended |

---

## 12. Quiz (for learners)

1. 5 replicas, `minAvailable: 60%`. How many allowed disruptions? *(5 × 0.6 = 3 must stay → 2)*
2. Does a PDB stop pods dying when a node loses power? *(No — involuntary)*
3. Does `kubectl delete pod` respect PDBs? *(No)*
4. Why can a 1-replica + `minAvailable: 1` PDB block cluster upgrades? *(Allowed disruptions is always 0)*

---

## 13. Cleanup

```bash
kubectl uncordon $NODE1 $NODE2 2>/dev/null
kubectl delete namespace pdb-demo
# if you used kind:
kind delete cluster --name pdb-lab
```
