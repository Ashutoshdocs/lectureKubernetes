# PodDisruptionBudget (PDB): Teaching Demo

A hands-on course on **PodDisruptionBudgets**, run on the same 6-node kubeadm cluster as the
scheduling demo. There's a theory lesson first, then 10 labs. Each lab has a goal, the exact
commands, the output you should see and an explanation, and there's a quiz at the end.

```
                    ┌──────────────────────────┐
                    │  k8s-master  (tainted)   │  ← the "prober" pod runs here (never drained)
                    └────────────┬─────────────┘
   ┌──────────────── zone-a ─────┴──────────┐   ┌──────── zone-b ────────┐
   │  worker-a1    worker-a2    worker-a3   │   │  worker-b1  worker-b2  │
   └────────────────────────────────────────┘   └────────────────────────┘
```

## Course map

| # | Lab | What you will see | Manifest | ~Time |
|---|-----|-------------------|----------|------|
| — | Lesson: theory | Why PDBs exist, how eviction works, the math | — | 15 min |
| 1 | Create a PDB and read its status | `ALLOWED DISRUPTIONS` explained | `01`, `02` | 10 min |
| 2 | Evict vs delete | Eviction API returns **429** and `delete` ignores the PDB | `01`, `02` | 10 min |
| 3 | minAvailable vs maxUnavailable | How each one behaves when you scale | `02`, `03` | 10 min |
| 4 | Percentages and rounding | The same "50%" gives different results | `04` | 5 min |
| 5 | ⭐ Downtime without vs with a PDB | Live **OK/FAIL** request log | `05`, `06` | 15 min |
| 6 | Draining a whole zone | Zone-b maintenance while the app stays up | `01`, `02` | 10 min |
| 7 | Unhealthy pods | `unhealthyPodEvictionPolicy` | `07` | 10 min |
| 8 | Anti-patterns | Blocking PDBs, overlapping PDBs, selector typos | `08`–`10` | 15 min |
| 9 | StatefulSet quorum | Two admins draining at once without losing quorum | `11` | 10 min |
| 10 | What a PDB does NOT protect | delete, scale-down, rolling updates, node crashes | `01`, `02` | 10 min |

## Repository layout

```
k8s-pdb-demo/
├── README.md
├── manifests/
│   ├── 00-namespace.yaml              # namespace pdb-demo
│   ├── 01-web-app.yaml                # web: 6 replicas + Service (base app)
│   ├── 02-pdb-min-available.yaml      # web-pdb  minAvailable: 4
│   ├── 03-pdb-max-unavailable.yaml    # web-pdb  maxUnavailable: 1 (replaces 02)
│   ├── 04-pdb-percentages.yaml        # pct-min / pct-max  (rounding)
│   ├── 05-downtime-app.yaml           # frontend (3) + Service + prober pod
│   ├── 06-downtime-pdb.yaml           # frontend-pdb minAvailable: 2
│   ├── 07-unhealthy-pods.yaml         # flaky (4) + PDB with unhealthyPodEvictionPolicy
│   ├── 08-blocking-pdbs.yaml          # single-replica and maxUnavailable: 0 (anti-patterns)
│   ├── 09-overlapping-pdbs.yaml       # second PDB on the same pods (anti-pattern)
│   ├── 10-wrong-selector-pdb.yaml     # selector typo (anti-pattern)
│   ├── 11-statefulset-quorum.yaml     # 3-member quorum StatefulSet + PDB
│   └── eviction-template.json         # raw Eviction object (for curl / manual use)
└── scripts/
    ├── label-nodes.sh       # zone labels (idempotent)
    ├── pdb-status.sh        # PDB math + pods + nodes, one shot
    ├── pdb-watch.sh         # the same, live (keep it open in terminal 2)
    ├── evict.sh             # evict ONE pod through the Eviction API (what drain does)
    ├── stack-on-node.sh     # Lab 5: put all frontend pods on one node
    ├── drain-zone.sh        # Lab 6: cordon a zone, then drain it node by node
    └── reset.sh             # clean baseline between labs
```

## Setup (once)

Run everything on **k8s-master**:

```bash
scp -r k8s-pdb-demo azureuser@<k8s-master-public-ip>:~     # from your laptop
ssh azureuser@<k8s-master-public-ip>
cd ~/k8s-pdb-demo
chmod +x scripts/*.sh
./scripts/label-nodes.sh            # zone-a = a1,a2,a3 ; zone-b = b1,b2
./scripts/reset.sh                  # creates namespace pdb-demo
```

Keep **two terminals** open on the master:

| Terminal 1: commands | Terminal 2: live dashboard |
|---|---|
| `cd ~/k8s-pdb-demo` | `cd ~/k8s-pdb-demo && ./scripts/pdb-watch.sh` |

---

# Lesson: Theory

## 1. The problem

You have 3 replicas, so you think you're highly available. Then someone runs `kubectl drain` to patch a
node, and the scheduler happened to put **all 3 replicas on that node**. All 3 are evicted at the same
moment, and your app is down until the new pods start somewhere else.

A **PodDisruptionBudget** is a promise from the app owner to the cluster:

> "You may take my pods down for maintenance, but **never more than X at a time**
> (or never leave fewer than Y running)."

## 2. Voluntary vs involuntary disruptions

A PDB only limits **voluntary** disruptions that go through the **Eviction API**.

| Disruption | Type | Does the PDB stop it? |
|---|---|---|
| `kubectl drain` | voluntary (Eviction API) | ✅ **Yes** |
| Cluster Autoscaler scaling a node down | voluntary (Eviction API) | ✅ Yes |
| Managed node-pool upgrade (AKS/EKS/GKE) | voluntary (Eviction API) | ✅ Yes (usually with a timeout) |
| Calling the Eviction API directly (`scripts/evict.sh`) | voluntary | ✅ Yes |
| `kubectl delete pod` | voluntary, **but not an eviction** | ❌ No |
| `kubectl scale --replicas=1` | voluntary, owner action | ❌ No |
| Deployment rolling update | controlled by the Deployment's `maxUnavailable` | ❌ No |
| `kubectl drain --disable-eviction` | uses DELETE | ❌ No |
| Node crash, VM deleted, kernel panic | involuntary | ❌ No |
| Node-pressure eviction by the kubelet (OOM, disk) | involuntary | ❌ No |
| Taint-based eviction (`NoExecute`, node NotReady) | not an eviction request | ❌ No |

## 3. How an eviction is decided

```
 kubectl drain worker-b1
        │  (1) cordon worker-b1
        │  (2) for every pod on the node: POST /api/v1/namespaces/<ns>/pods/<pod>/eviction
        ▼
 ┌───────────────────────┐   find PDBs whose selector matches the pod
 │  kube-apiserver        │───────────────────────────────────────────┐
 │  eviction subresource  │                                           │
 └───────────────────────┘                                            ▼
        │                    0 PDBs   → allowed (201)
        │                    2+ PDBs  → error 500 "more than one PodDisruptionBudget"
        │                    1 PDB    → is status.disruptionsAllowed ≥ 1 ?
        │                                   yes → 201, pod is deleted gracefully,
        │                                         disruptionsAllowed is decremented immediately
        │                                   no  → 429 TooManyRequests
        ▼
 kubectl drain gets 429 → "error when evicting ... (will retry after 5s)"
                       → keeps retrying until the pod is allowed or --timeout expires
```

The **disruption controller** in kube-controller-manager continuously updates the PDB `status`.

## 4. The spec: you choose ONE of two fields

```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: web-pdb
spec:
  minAvailable: 4            # OR maxUnavailable: 1   (never both)
                             # each is an integer or a percentage like "50%"
  selector:                  # which pods are protected (same namespace)
    matchLabels:
      app: web
  unhealthyPodEvictionPolicy: IfHealthyBudget   # optional; or AlwaysAllow (Lab 7)
```

| Field | Meaning | Good for |
|---|---|---|
| `minAvailable: N` | at least N pods must stay **Ready** | quorum systems ("I need 2 of 3") |
| `maxUnavailable: N` | at most N pods may be down | stateless apps; works at any replica count |

## 5. The status: learn to read it

```bash
kubectl get pdb web-pdb -n pdb-demo -o yaml
```

| Status field | Meaning |
|---|---|
| `expectedPods` | number of pods the owning controller wants (replicas) |
| `currentHealthy` | matching pods that are **Running and Ready** right now |
| `desiredHealthy` | the minimum healthy count the budget requires |
| `disruptionsAllowed` | `currentHealthy − desiredHealthy` (never below 0): how many evictions are allowed **right now** |

| Spec | expectedPods | desiredHealthy | disruptionsAllowed (all healthy) |
|---|---|---|---|
| `minAvailable: 4` | 6 | 4 | 2 |
| `maxUnavailable: 1` | 6 | 5 | 1 |
| `minAvailable: "50%"` | 5 | ceil(2.5) = **3** | 2 |
| `maxUnavailable: "50%"` | 5 | 5 − ceil(2.5) = **2** | 3 |
| `minAvailable: 1` | 1 | 1 | **0** ⚠ blocks drain forever |
| `maxUnavailable: 0` | any | all | **0** ⚠ blocks drain forever |

> **Rule:** a pod only counts as healthy when it is **Ready**. Without a readiness probe, a
> pod counts as healthy the moment its container starts, which makes the PDB much weaker.

---

# Lab 1: Create a PDB and read its status

**Goal:** see the PDB math in practice.

```bash
kubectl apply -f manifests/01-web-app.yaml
kubectl rollout status deploy/web -n pdb-demo
kubectl apply -f manifests/02-pdb-min-available.yaml
```

```bash
kubectl get pdb -n pdb-demo
```

```
NAME      MIN AVAILABLE   MAX UNAVAILABLE   ALLOWED DISRUPTIONS   AGE
web-pdb   4               N/A               2                     5s
```

Look at the full status:

```bash
kubectl get pdb web-pdb -n pdb-demo -o jsonpath='{.status}' | jq
```

```json
{ "currentHealthy": 6, "desiredHealthy": 4, "disruptionsAllowed": 2, "expectedPods": 6, ... }
```

```bash
kubectl describe pdb web-pdb -n pdb-demo
./scripts/pdb-status.sh web
```

**Explanation:** 6 healthy − 4 required = **2 pods can be disrupted right now**.

👉 Keep `web` and `web-pdb` for Lab 2.

---

# Lab 2: Evict vs delete

**Goal:** see the Eviction API refuse a request (429), and see that `kubectl delete` ignores the PDB.

### 2.1 Evict pods one by one

```bash
PODS=($(kubectl get pods -n pdb-demo -l app=web -o jsonpath='{.items[*].metadata.name}'))
./scripts/evict.sh ${PODS[0]}      # ALLOWED  (ALLOWED DISRUPTIONS: 2 → 1)
./scripts/evict.sh ${PODS[1]}      # ALLOWED  (1 → 0)
./scripts/evict.sh ${PODS[2]}      # REFUSED
```

The third call fails:

```
Error from server (TooManyRequests): Cannot evict pod as it would violate the pod's disruption budget.
```

Watch terminal 2. After about 10 seconds the Deployment has created 2 replacement pods, they become
**Ready**, `HEALTHY` returns to 6 and `ALLOWED` returns to 2. Run the third eviction again and it now succeeds.

> This is the whole idea of a PDB: **one disruption at a time, and the next one only after the
> app has recovered.** `kubectl drain` simply runs this loop for you, retrying every 5 seconds.

What `evict.sh` sends (the same request drain sends):

```bash
kubectl create --raw /api/v1/namespaces/pdb-demo/pods/<pod>/eviction -f - <<EOF
{"apiVersion":"policy/v1","kind":"Eviction","metadata":{"name":"<pod>","namespace":"pdb-demo"}}
EOF
```

### 2.2 `kubectl delete` ignores the PDB

```bash
kubectl delete pod -n pdb-demo -l app=web --wait=false     # deletes ALL 6 at once
./scripts/pdb-status.sh web
```

All 6 pods terminate together and `HEALTHY` drops toward 0. **The PDB did nothing**, because
`delete` is not an eviction. PDBs protect against *the platform* (drain, autoscaler, upgrades), not against
people with delete permissions. RBAC controls who can delete pods.

```bash
kubectl rollout status deploy/web -n pdb-demo      # wait for recovery
```

---

# Lab 3: minAvailable vs maxUnavailable when scaling

**Goal:** understand why `maxUnavailable` is usually the better choice for stateless apps.

### 3.1 minAvailable: 4

```bash
kubectl scale deploy web -n pdb-demo --replicas=4
kubectl get pdb web-pdb -n pdb-demo        # ALLOWED DISRUPTIONS: 0   ← drain is now blocked!
kubectl scale deploy web -n pdb-demo --replicas=10
kubectl get pdb web-pdb -n pdb-demo        # ALLOWED DISRUPTIONS: 6
```

A fixed `minAvailable` doesn't follow scaling. Scale down to 4 and maintenance is blocked; scale up to 10
and drain can suddenly evict 6 pods at once.

### 3.2 maxUnavailable: 1

```bash
kubectl apply -f manifests/03-pdb-max-unavailable.yaml     # same name, so it replaces web-pdb
kubectl scale deploy web -n pdb-demo --replicas=4
kubectl get pdb web-pdb -n pdb-demo        # ALLOWED: 1
kubectl scale deploy web -n pdb-demo --replicas=10
kubectl get pdb web-pdb -n pdb-demo        # ALLOWED: 1
kubectl scale deploy web -n pdb-demo --replicas=6
```

| Replicas | `minAvailable: 4` allows | `maxUnavailable: 1` allows |
|---|---|---|
| 4 | 0 ⚠ | 1 |
| 6 | 2 | 1 |
| 10 | 6 | 1 |

> **Recommendation:** use `maxUnavailable` for stateless apps (the result is the same at any scale) and
> `minAvailable` when you have a hard quorum number (Lab 9).

```bash
./scripts/reset.sh
```

---

# Lab 4: Percentages and rounding

**Goal:** see that Kubernetes always **rounds the percentage up**, which makes the same "50%" give opposite results.

```bash
kubectl apply -f manifests/04-pdb-percentages.yaml
kubectl rollout status deploy/pct-min -n pdb-demo; kubectl rollout status deploy/pct-max -n pdb-demo
kubectl get pdb -n pdb-demo -o custom-columns='NAME:.metadata.name,MIN:.spec.minAvailable,MAX:.spec.maxUnavailable,DESIRED:.status.desiredHealthy,ALLOWED:.status.disruptionsAllowed'
```

```
NAME          MIN   MAX    DESIRED   ALLOWED
pct-max-pdb   N/A   50%    2         3
pct-min-pdb   50%   N/A    3         2
```

| | Calculation (5 replicas) | Must stay | Can go |
|---|---|---|---|
| `minAvailable: 50%` | ceil(2.5) = 3 must **stay** | 3 | 2 |
| `maxUnavailable: 50%` | ceil(2.5) = 3 may **go** | 2 | 3 |

**Exercise:** predict, then check.

```bash
kubectl patch pdb pct-max-pdb -n pdb-demo --type merge -p '{"spec":{"maxUnavailable":"30%"}}'
kubectl get pdb pct-max-pdb -n pdb-demo     # 30% of 5 = 1.5 → ceil 2 → ALLOWED 2
kubectl patch pdb pct-min-pdb -n pdb-demo --type merge -p '{"spec":{"minAvailable":"10%"}}'
kubectl get pdb pct-min-pdb -n pdb-demo     # 10% of 5 = 0.5 → ceil 1 must stay → ALLOWED 4
```

```bash
./scripts/reset.sh
```

---

# Lab 5: ⭐ Downtime without vs with a PDB

**Goal:** prove the value of a PDB with real traffic.

**Setup:** `frontend` has 3 replicas, **all on worker-b1** (the worst case). Pods take about 15 seconds to
become Ready. A `prober` pod on the master calls the Service every 0.5 seconds.

Use three terminals:

| Terminal 1 | Terminal 2 | Terminal 3 |
|---|---|---|
| commands | `./scripts/pdb-watch.sh frontend` | `kubectl logs -f prober -n pdb-demo` |

### Round 1: no PDB

```bash
./scripts/stack-on-node.sh worker-b1
kubectl get pods -n pdb-demo -l app=frontend -o wide        # all 3 on worker-b1
# terminal 3 shows:  12:00:01 OK  12:00:01 OK ...

kubectl drain worker-b1 --ignore-daemonsets --delete-emptydir-data
```

**Expected:** drain evicts **all 3 pods at the same moment**, and terminal 3 shows an outage:

```
12:00:10 OK
12:00:11 FAIL  <-------- OUTAGE
12:00:12 FAIL  <-------- OUTAGE
...                      (~15-20 seconds)
12:00:29 OK
```

Count the FAIL lines. **That is the downtime your users would have seen.**

```bash
kubectl uncordon worker-b1
kubectl delete -f manifests/05-downtime-app.yaml --wait=true
```

### Round 2: with a PDB

```bash
./scripts/stack-on-node.sh worker-b1                        # same worst-case placement
kubectl apply -f manifests/06-downtime-pdb.yaml             # minAvailable: 2  → ALLOWED 1
kubectl get pdb frontend-pdb -n pdb-demo

kubectl drain worker-b1 --ignore-daemonsets --delete-emptydir-data
```

**Expected drain output:**

```
evicting pod pdb-demo/frontend-xxx-aaa
evicting pod pdb-demo/frontend-xxx-bbb
evicting pod pdb-demo/frontend-xxx-ccc
error when evicting pods/"frontend-xxx-bbb" -n "pdb-demo" (will retry after 5s): Cannot evict pod as it would violate the pod's disruption budget.
error when evicting pods/"frontend-xxx-ccc" -n "pdb-demo" (will retry after 5s): Cannot evict pod as it would violate the pod's disruption budget.
...  (repeats while the first replacement starts up, ~15 s)
pod/frontend-xxx-aaa evicted
pod/frontend-xxx-bbb evicted
...
node/worker-b1 drained
```

Terminal 3 shows **only OK, with zero FAIL lines.** The drain takes longer (about 45 seconds instead of
about 5), but users notice nothing. That trade-off is the point.

**What happened:**

```
t=0s   3 healthy, allowed 1 → evict pod A        (2 serving traffic)
       pods B, C → 429, retry every 5s
t=15s  replacement A' Ready → 3 healthy, allowed 1 → evict pod B
t=30s  replacement B' Ready → evict pod C
t=45s  replacement C' Ready → drain complete
```

> The `preStop: sleep 5` in the manifest matters too. It gives kube-proxy time to remove the endpoint
> before nginx stops, so in-flight requests aren't dropped.

```bash
kubectl uncordon worker-b1
./scripts/reset.sh
```

---

# Lab 6: Draining a whole zone

**Goal:** take **all of zone-b** (worker-b1 and worker-b2) down for maintenance while `web` stays at 4 or more Ready pods.

```bash
kubectl apply -f manifests/01-web-app.yaml
kubectl apply -f manifests/02-pdb-min-available.yaml        # minAvailable 4 → ALLOWED 2
kubectl rollout status deploy/web -n pdb-demo
kubectl get pods -n pdb-demo -l app=web -o wide              # about 3 in zone-a, 3 in zone-b
```

```bash
./scripts/drain-zone.sh zone-b
```

The script:

1. **Cordons both zone-b nodes first.** Otherwise pods evicted from worker-b1 could be rescheduled
   onto worker-b2 and then be evicted a second time.
2. Drains worker-b1, then worker-b2, **one node at a time**.
3. Lets the PDB pace the evictions: at most 2 `web` pods are down at any moment.

**Watch terminal 2:** `HEALTHY` never drops below 4. When the script finishes, all 6 pods are in zone-a.

```bash
./scripts/pdb-status.sh web
./scripts/drain-zone.sh zone-b --undo        # maintenance done, uncordon zone-b
```

> Uncordoning doesn't move pods back. To rebalance across zones, run
> `kubectl rollout restart deploy/web -n pdb-demo`. That's a rolling update, so the Deployment's own
> `maxUnavailable: 1` paces it, not the PDB.

### Gotcha: a PDB plus hard zone spreading can deadlock

Try this if you want to see a drain stuck forever:

```bash
kubectl patch deploy web -n pdb-demo --type json -p '[{"op":"replace","path":"/spec/template/spec/topologySpreadConstraints/0/whenUnsatisfiable","value":"DoNotSchedule"}]'
kubectl rollout status deploy/web -n pdb-demo
timeout 90 ./scripts/drain-zone.sh zone-b
kubectl get pods -n pdb-demo -l app=web | grep Pending
```

Replacement pods can't go to zone-b (cordoned), and the hard `maxSkew: 1` rule may not let them pile into
zone-a, so they stay **Pending**. Healthy pods never recover, the PDB stays at `ALLOWED 0`, and drain retries forever.
**Fix:** use `whenUnsatisfiable: ScheduleAnyway`, or `nodeTaintsPolicy: Honor` so cordoned nodes are ignored when counting zones.

```bash
./scripts/drain-zone.sh zone-b --undo
./scripts/reset.sh
```

---

# Lab 7: Unhealthy pods and `unhealthyPodEvictionPolicy`

**Goal:** understand how pods that are Running but **not Ready** count against the budget.

```bash
kubectl apply -f manifests/07-unhealthy-pods.yaml
kubectl rollout status deploy/flaky -n pdb-demo
kubectl get pdb flaky-pdb -n pdb-demo           # 4 healthy, desired 3, ALLOWED 1
```

### 7.1 Break 2 of the 4 pods

```bash
P=($(kubectl get pods -n pdb-demo -l app=flaky -o jsonpath='{.items[*].metadata.name}'))
kubectl exec -n pdb-demo ${P[0]} -- rm /tmp/ready
kubectl exec -n pdb-demo ${P[1]} -- rm /tmp/ready
sleep 5
kubectl get pods -n pdb-demo -l app=flaky        # two pods show READY 0/1
./scripts/pdb-status.sh flaky                    # HEALTHY 2, DESIRED 3, ALLOWED 0
```

### 7.2 Default policy: `IfHealthyBudget`

Try to evict one of the **broken** pods:

```bash
./scripts/evict.sh ${P[0]}       # REFUSED (429)
```

The broken pod serves no traffic, but the app is **below** its budget (2 < 3), so under
`IfHealthyBudget` even the unhealthy pod can't be evicted. A drain on that node would get stuck,
which is a common real-world cause of stuck node upgrades (for example a crash-looping pod).

### 7.3 `AlwaysAllow`

```bash
kubectl patch pdb flaky-pdb -n pdb-demo --type merge -p '{"spec":{"unhealthyPodEvictionPolicy":"AlwaysAllow"}}'
./scripts/evict.sh ${P[0]}       # ALLOWED: unhealthy pods can always be evicted now
./scripts/evict.sh ${P[2]}       # P[2] is HEALTHY → still REFUSED (budget not met)
```

Evicting the broken pod is safe and helps. Its replacement starts healthy (the container creates
`/tmp/ready` on start), so the app recovers. Evicting a healthy pod is still refused.

| Policy | Not-Ready pod can be evicted… |
|---|---|
| `IfHealthyBudget` (default) | only if `currentHealthy ≥ desiredHealthy` |
| `AlwaysAllow` | always (**recommended** for most apps) |

> Pods that are not Running at all (Pending, Failed, Succeeded) can always be evicted, whatever the policy.

```bash
./scripts/reset.sh
```

---

# Lab 8: Anti-patterns

### 8a. PDBs that block maintenance forever

```bash
kubectl apply -f manifests/08-blocking-pdbs.yaml
kubectl rollout status deploy/single -n pdb-demo; kubectl rollout status deploy/locked -n pdb-demo
kubectl get pdb -n pdb-demo
```

```
NAME         MIN AVAILABLE   MAX UNAVAILABLE   ALLOWED DISRUPTIONS
locked-pdb   N/A             0                 0
single-pdb   1               N/A               0
```

Both pods are pinned to worker-a1. Try to drain it with a timeout:

```bash
kubectl drain worker-a1 --ignore-daemonsets --delete-emptydir-data --timeout=60s
```

```
error when evicting pods/"single-..." (will retry after 5s): Cannot evict pod as it would violate the pod's disruption budget.
...
error: unable to drain node "worker-a1" due to error: ... global timeout reached: 1m0s
```

The node is now **cordoned but not drained**, and stays that way until someone acts.

**How to get unstuck (best option first):**

| Option | Command | Note |
|---|---|---|
| 1. Scale up so a disruption is possible | `kubectl scale deploy single -n pdb-demo --replicas=2` | best, no risk |
| 2. Relax the PDB temporarily | `kubectl patch pdb locked-pdb -n pdb-demo --type merge -p '{"spec":{"maxUnavailable":1}}'` | tell the app owner |
| 3. Delete the PDB temporarily | `kubectl delete pdb single-pdb -n pdb-demo` | re-apply afterwards |
| 4. Bypass the PDB | `kubectl drain worker-a1 --ignore-daemonsets --disable-eviction` | ⚠ uses DELETE, so it ignores every PDB |

Here the `single` pod is also pinned to worker-a1 with a `nodeSelector`. Even after scaling up, its
replacement can't schedule anywhere else, so its pods go Pending. That's another reason why
"1 replica + node pinning + PDB" is unmaintainable.

```bash
./scripts/reset.sh
```

> **Rules:** never use `maxUnavailable: 0` or `minAvailable: 100%`. Don't put `minAvailable: 1` on a single-replica app.
> If an app truly can't tolerate any disruption, it needs more replicas, not a stricter PDB.

### 8b. Two PDBs selecting the same pods

```bash
kubectl apply -f manifests/01-web-app.yaml -f manifests/02-pdb-min-available.yaml
kubectl rollout status deploy/web -n pdb-demo
kubectl apply -f manifests/09-overlapping-pdbs.yaml        # selects tier=frontend, which web pods also have
./scripts/evict.sh $(kubectl get pod -n pdb-demo -l app=web -o jsonpath='{.items[0].metadata.name}')
```

```
Error from server (InternalError): ... This pod has more than one PodDisruptionBudget, which the eviction subresource does not support.
```

Every eviction of a `web` pod now fails, and drains get stuck. Find the overlap:

```bash
kubectl get pdb -n pdb-demo -o custom-columns='NAME:.metadata.name,SELECTOR:.spec.selector.matchLabels'
kubectl delete -f manifests/09-overlapping-pdbs.yaml
```

### 8c. A selector that matches nothing

```bash
kubectl apply -f manifests/10-wrong-selector-pdb.yaml
kubectl get pdb typo-pdb -n pdb-demo -o jsonpath='{.status}' | jq
# expectedPods: 0, currentHealthy: 0, disruptionsAllowed: 0
```

The API accepts it without any error, and it **protects nothing**. Always check `expectedPods`:

```bash
kubectl get pdb -A -o custom-columns='NS:.metadata.namespace,NAME:.metadata.name,EXPECTED:.status.expectedPods' | awk 'NR==1 || $3==0'
```

```bash
./scripts/reset.sh
```

---

# Lab 9: StatefulSet quorum and two admins draining at once

**Goal:** a 3-member quorum system (the etcd / ZooKeeper / Kafka pattern) must **always keep 2 members**,
even when two nodes are drained at the same time.

```bash
kubectl apply -f manifests/11-statefulset-quorum.yaml
kubectl rollout status sts/quorum -n pdb-demo
kubectl get pods -n pdb-demo -l app=quorum -o wide      # 3 members on 3 different nodes
kubectl get pdb quorum-pdb -n pdb-demo                  # minAvailable 2 → ALLOWED 1
```

Drain the nodes of `quorum-0` and `quorum-1` **in parallel**, as two admins might:

```bash
N0=$(kubectl get pod quorum-0 -n pdb-demo -o jsonpath='{.spec.nodeName}')
N1=$(kubectl get pod quorum-1 -n pdb-demo -o jsonpath='{.spec.nodeName}')
echo "draining $N0 and $N1 at the same time"

kubectl drain $N0 --ignore-daemonsets --delete-emptydir-data > /tmp/drain0.log 2>&1 &
kubectl drain $N1 --ignore-daemonsets --delete-emptydir-data > /tmp/drain1.log 2>&1 &
```

**Watch terminal 2:**

- One member (say `quorum-0`) is evicted right away. `ALLOWED` becomes 0, but 2 members are still Ready.
- The other drain logs `Cannot evict pod ... disruption budget` every 5 seconds.
- The StatefulSet recreates `quorum-0` **with the same name** on a free node. After about 15 seconds it's Ready, `ALLOWED` goes back to 1, and only then is `quorum-1` evicted.
- **Ready members never drop below 2, so quorum is never lost.**

```bash
wait; cat /tmp/drain0.log /tmp/drain1.log
kubectl get pods -n pdb-demo -l app=quorum -o wide
kubectl uncordon $N0 $N1
./scripts/reset.sh
```

> For quorum systems with N members, use `minAvailable: floor(N/2)+1` (3 → 2, 5 → 3).

---

# Lab 10: What a PDB does NOT protect against

```bash
kubectl apply -f manifests/01-web-app.yaml -f manifests/02-pdb-min-available.yaml
kubectl rollout status deploy/web -n pdb-demo
```

### 10.1 Scale-down

```bash
kubectl scale deploy web -n pdb-demo --replicas=2       # succeeds instantly
kubectl get pdb web-pdb -n pdb-demo                     # HEALTHY 2 < DESIRED 4, ALLOWED 0
kubectl scale deploy web -n pdb-demo --replicas=6
```

The PDB doesn't stop the owner from scaling down. It just reports that the budget is violated.

### 10.2 Rolling update

```bash
kubectl patch deploy web -n pdb-demo -p '{"spec":{"strategy":{"rollingUpdate":{"maxUnavailable":"100%","maxSurge":0}}}}'
kubectl rollout restart deploy/web -n pdb-demo
./scripts/pdb-status.sh web                             # all 6 pods replaced at once, HEALTHY ≈ 0
```

Rolling updates are controlled by the Deployment's **own** `strategy.rollingUpdate.maxUnavailable`. **Set both** values sensibly:

```bash
kubectl patch deploy web -n pdb-demo -p '{"spec":{"strategy":{"rollingUpdate":{"maxUnavailable":1,"maxSurge":1}}}}'
```

### 10.3 `kubectl delete` and `drain --disable-eviction`

Already covered in Labs 2.2 and 8a. Both use DELETE, not eviction.

### 10.4 Node failure (optional, run from your laptop)

```powershell
az vm deallocate -g rg-k8s-scheduling-demo -n worker-b2     # simulate a hard crash
```

```bash
kubectl get nodes -w            # worker-b2 → NotReady
# About 5 min later (default toleration for node.kubernetes.io/unreachable is 300s) the pods are
# removed and recreated elsewhere. The PDB is NOT consulted, and ALLOWED can go to 0 or below the budget.
```

```powershell
az vm start -g rg-k8s-scheduling-demo -n worker-b2
```

> A PDB **limits planned maintenance**. It doesn't replace real HA: enough replicas, pod anti-affinity
> or topology spread across nodes and zones, and readiness probes.

```bash
./scripts/reset.sh
```

---

# Best practices (summary)

1. **Every production workload with 2 or more replicas gets a PDB.** One PDB per workload, and no overlapping selectors.
2. **Stateless apps:** `maxUnavailable: 1` (or `"25%"` for large deployments).
3. **Quorum or stateful apps:** `minAvailable: floor(N/2)+1`.
4. **Never** use `maxUnavailable: 0`, `minAvailable: 100%`, or `minAvailable: 1` on a single replica. These block maintenance forever.
5. **Use readiness probes.** The PDB's idea of "healthy" comes from them.
6. Set **`unhealthyPodEvictionPolicy: AlwaysAllow`** so crash-looping pods don't block node upgrades.
7. Combine with **spreading** (pod anti-affinity or topologySpreadConstraints). A PDB paces evictions; spreading reduces how many are needed.
8. Add a **`preStop` sleep** and a sensible `terminationGracePeriodSeconds` for graceful shutdown.
9. Remember that the Deployment's `rollingUpdate.maxUnavailable` covers rollouts and the PDB covers evictions. **Configure both.**
10. Check regularly: `expectedPods == 0` (typo) or `disruptionsAllowed == 0` for a long time (blocker).

# Cheat sheet

```bash
# List / inspect
kubectl get pdb -A
kubectl describe pdb <name> -n <ns>
kubectl get pdb <name> -n <ns> -o jsonpath='{.status}' | jq

# Create imperatively
kubectl create pdb web-pdb -n pdb-demo --selector=app=web --max-unavailable=1
kubectl create pdb web-pdb -n pdb-demo --selector=app=web --min-available=50%

# Change
kubectl patch pdb web-pdb -n pdb-demo --type merge -p '{"spec":{"maxUnavailable":2}}'
kubectl patch pdb web-pdb -n pdb-demo --type merge -p '{"spec":{"unhealthyPodEvictionPolicy":"AlwaysAllow"}}'

# Evict one pod (PDB-checked)
./scripts/evict.sh <pod> [ns]

# Drain (PDB-checked)
kubectl drain <node> --ignore-daemonsets --delete-emptydir-data --timeout=300s
kubectl drain <node> --ignore-daemonsets --dry-run=client          # preview
kubectl drain <node> --ignore-daemonsets --disable-eviction        # ⚠ bypass PDBs

# Find problem PDBs
kubectl get pdb -A -o custom-columns='NS:.metadata.namespace,NAME:.metadata.name,EXPECTED:.status.expectedPods,ALLOWED:.status.disruptionsAllowed'
```

# Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Drain retries `Cannot evict pod ... disruption budget` forever | `ALLOWED 0`: single replica, `maxUnavailable: 0`, or unhealthy pods | Lab 8a options; Lab 7 `AlwaysAllow` |
| `more than one PodDisruptionBudget` | overlapping selectors | delete or fix one PDB (Lab 8b) |
| PDB shows `EXPECTED 0` | selector typo or wrong namespace | fix the selector (Lab 8c) |
| Drain stuck and replacement pods Pending | nowhere to schedule (hard spread, node affinity, resources) | Lab 6 gotcha; check `kubectl describe pod` |
| Outage even with a PDB | rolling update, scale-down, delete, or node crash | Lab 10; more replicas and spreading |
| `ALLOWED` bigger than expected | `minAvailable` fixed while replicas grew | use `maxUnavailable` (Lab 3) |

---

# Quiz

<details><summary><b>Q1.</b> 8 replicas, <code>minAvailable: 6</code>, all Ready. How many pods can a drain evict at once?</summary>

**2** (8 − 6).
</details>

<details><summary><b>Q2.</b> 7 replicas, <code>maxUnavailable: "40%"</code>. What are desiredHealthy and disruptionsAllowed?</summary>

40% of 7 = 2.8 → rounded **up** to 3 may be unavailable. desiredHealthy = 7 − 3 = **4**, allowed = **3**.
</details>

<details><summary><b>Q3.</b> A PDB with <code>minAvailable: 3</code> covers a 3-replica Deployment. You run <code>kubectl delete pod</code> on one pod. What happens?</summary>

The pod is deleted immediately. `delete` doesn't use the Eviction API, so PDBs don't apply.
</details>

<details><summary><b>Q4.</b> Why does <code>kubectl drain</code> hang on a node running a 1-replica app with <code>minAvailable: 1</code>?</summary>

disruptionsAllowed = 1 − 1 = 0, so every eviction returns 429 and drain retries until `--timeout`. Fix it by scaling up, relaxing or deleting the PDB, or (risky) using `--disable-eviction`.
</details>

<details><summary><b>Q5.</b> 4 replicas, <code>minAvailable: 3</code>, 2 pods are not Ready. Can you evict a not-Ready pod?</summary>

With the default `IfHealthyBudget`, **no** (currentHealthy 2 < 3). With `AlwaysAllow`, **yes**.
</details>

<details><summary><b>Q6.</b> Does a PDB slow down <code>kubectl rollout restart</code>?</summary>

No. Rollouts are paced by the Deployment's `strategy.rollingUpdate.maxUnavailable` and `maxSurge`.
</details>

<details><summary><b>Q7.</b> A 5-member ZooKeeper ensemble. Which PDB?</summary>

Quorum is 3, so `minAvailable: 3` (equivalent to `maxUnavailable: 2`).
</details>

<details><summary><b>Q8.</b> Two PDBs both select <code>app=web</code>. What does drain do?</summary>

Each eviction fails with "more than one PodDisruptionBudget", so drain keeps retrying and never completes.
</details>

<details><summary><b>Q9.</b> Why cordon all nodes of a zone before draining them one by one?</summary>

Otherwise pods evicted from the first node can be rescheduled onto another node in the same zone and get evicted again, which wastes disruption budget and time.
</details>

---

## Cleanup

```bash
./scripts/reset.sh                       # labs only
kubectl delete namespace pdb-demo        # everything
```
