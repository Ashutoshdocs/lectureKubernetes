#!/usr/bin/env bash
# One-shot dashboard: PDB math, pods (ready + node), node schedulability.
# Usage: ./pdb-status.sh [app-label]      e.g. ./pdb-status.sh web
NS=pdb-demo
SEL=${1:+-l app=$1}

echo "=== PodDisruptionBudgets ==================================================="
kubectl get pdb -n "$NS" -o custom-columns='NAME:.metadata.name,MIN-AVAIL:.spec.minAvailable,MAX-UNAVAIL:.spec.maxUnavailable,EXPECTED:.status.expectedPods,HEALTHY:.status.currentHealthy,DESIRED:.status.desiredHealthy,ALLOWED:.status.disruptionsAllowed' 2>/dev/null

echo
echo "=== Pods ===================================================================="
# shellcheck disable=SC2086
kubectl get pods -n "$NS" $SEL --sort-by=.spec.nodeName \
  -o custom-columns='POD:.metadata.name,PHASE:.status.phase,READY:.status.containerStatuses[0].ready,NODE:.spec.nodeName,DELETING:.metadata.deletionTimestamp' 2>/dev/null

echo
echo "=== Nodes ==================================================================="
kubectl get nodes -L topology.kubernetes.io/zone --no-headers |
  awk '{printf "%-12s %-28s zone=%s\n", $1, $2, $NF}'
