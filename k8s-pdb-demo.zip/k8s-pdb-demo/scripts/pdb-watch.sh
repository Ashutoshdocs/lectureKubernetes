#!/usr/bin/env bash
# Live dashboard - keep this running in a second terminal during every lab.
# Usage: ./pdb-watch.sh [app-label]
DIR="$(cd "$(dirname "$0")" && pwd)"
exec watch -n1 -t "$DIR/pdb-status.sh" "$@"
