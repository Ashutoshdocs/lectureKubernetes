#!/usr/bin/env bash
# Lab 5 setup: deploy 05-downtime-app.yaml with ALL frontend replicas on ONE node
# (simulates the worst-case scheduling that PDBs protect you from).
# Usage: ./stack-on-node.sh [node]     default: worker-b1
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET=${1:-worker-b1}
OTHERS=$(kubectl get nodes -l '!node-role.kubernetes.io/control-plane' -o jsonpath='{.items[*].metadata.name}' |
         tr ' ' '\n' | grep -vx "$TARGET")

echo ">> Temporarily cordoning every worker except $TARGET"
# shellcheck disable=SC2086
kubectl cordon $OTHERS

kubectl apply -f "$DIR/../manifests/05-downtime-app.yaml"
kubectl rollout status deploy/frontend -n pdb-demo --timeout=180s
kubectl wait pod/prober -n pdb-demo --for=condition=Ready --timeout=120s

echo ">> Uncordoning the other workers again"
# shellcheck disable=SC2086
kubectl uncordon $OTHERS

echo
kubectl get pods -n pdb-demo -l app=frontend -o wide
echo
echo ">> All 3 frontend pods are on $TARGET. Now: kubectl logs -f prober -n pdb-demo"
