#!/usr/bin/env bash
# Zone labels used by the PDB labs (same as the scheduling demo). Idempotent.
set -euo pipefail
for n in worker-a1 worker-a2 worker-a3; do kubectl label node "$n" topology.kubernetes.io/zone=zone-a --overwrite; done
for n in worker-b1 worker-b2;           do kubectl label node "$n" topology.kubernetes.io/zone=zone-b --overwrite; done
for n in worker-a1 worker-a2 worker-a3 worker-b1 worker-b2; do kubectl label node "$n" node-role.kubernetes.io/worker= --overwrite; done
kubectl get nodes -L topology.kubernetes.io/zone
