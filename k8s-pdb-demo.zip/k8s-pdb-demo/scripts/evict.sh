#!/usr/bin/env bash
# Evict ONE pod through the Eviction API - exactly what "kubectl drain" does per pod.
# Unlike "kubectl delete pod", an eviction is CHECKED against PodDisruptionBudgets.
#
# Usage:  ./evict.sh <pod-name> [namespace]
#         ./evict.sh $(kubectl get pod -n pdb-demo -l app=web -o name | head -1 | cut -d/ -f2)
#
# Results:
#   201 Success                 -> PDB allowed it, pod is terminating
#   429 TooManyRequests         -> PDB blocked it ("would violate the pod's disruption budget")
#   500 InternalError           -> pod is covered by MORE THAN ONE PDB
set -uo pipefail
POD=${1:?usage: evict.sh <pod-name> [namespace]}
NS=${2:-pdb-demo}

echo ">> Requesting eviction of pod/$POD in namespace $NS"
cat <<EOF | kubectl create --raw "/api/v1/namespaces/$NS/pods/$POD/eviction" -f -
{"apiVersion":"policy/v1","kind":"Eviction","metadata":{"name":"$POD","namespace":"$NS"}}
EOF
rc=$?
echo
if [[ $rc -eq 0 ]]; then
  echo ">> ALLOWED - pod is being evicted"
else
  echo ">> REFUSED - see the message above"
fi
exit $rc
