#!/usr/bin/env bash
# Drain every node of a zone, ONE NODE AT A TIME (the safe way), respecting PDBs.
# Usage:   ./drain-zone.sh zone-b
# Undo:    ./drain-zone.sh zone-b --undo      (uncordon all nodes of the zone)
set -euo pipefail
ZONE=${1:?usage: drain-zone.sh <zone> [--undo]}
NODES=$(kubectl get nodes -l "topology.kubernetes.io/zone=$ZONE" -o jsonpath='{.items[*].metadata.name}')
[[ -z "$NODES" ]] && { echo "No nodes labelled topology.kubernetes.io/zone=$ZONE"; exit 1; }

if [[ "${2:-}" == "--undo" ]]; then
  for n in $NODES; do kubectl uncordon "$n"; done
  exit 0
fi

echo ">> Zone $ZONE contains: $NODES"
# Cordon the WHOLE zone first - otherwise pods evicted from node 1 may be
# rescheduled onto node 2 of the same zone and get evicted a second time.
for n in $NODES; do kubectl cordon "$n"; done

for n in $NODES; do
  echo
  echo "================ draining $n  ($(date +%T)) ================"
  kubectl drain "$n" \
    --ignore-daemonsets \
    --delete-emptydir-data \
    --grace-period=30 \
    --timeout=600s
  echo "================ $n drained   ($(date +%T)) ================"
done
echo
echo ">> Zone $ZONE is empty and cordoned. Do your maintenance, then: ./drain-zone.sh $ZONE --undo"
