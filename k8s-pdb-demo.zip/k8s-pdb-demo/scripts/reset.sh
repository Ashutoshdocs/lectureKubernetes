#!/usr/bin/env bash
# Back to a clean baseline between labs: delete all lab objects, uncordon all nodes.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"

# stop any drain still running in the background from this shell session
pkill -f "kubectl drain" 2>/dev/null || true

echo ">> Deleting namespace pdb-demo"
kubectl delete namespace pdb-demo --ignore-not-found --wait=true

echo ">> Uncordoning all workers"
for n in $(kubectl get nodes -l '!node-role.kubernetes.io/control-plane' -o jsonpath='{.items[*].metadata.name}'); do
  kubectl uncordon "$n" >/dev/null && echo "   $n uncordoned"
done

kubectl apply -f "$DIR/../manifests/00-namespace.yaml"
echo ">> Reset complete"
